.. cmake-module:: ../../Modules/FindCoin3D.cmake
