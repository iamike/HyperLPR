.. cmake-module:: ../../Modules/FindGit.cmake
