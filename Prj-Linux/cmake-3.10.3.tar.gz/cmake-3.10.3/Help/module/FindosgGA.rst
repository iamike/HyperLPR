.. cmake-module:: ../../Modules/FindosgGA.cmake
